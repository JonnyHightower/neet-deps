#!/bin/bash

# This is the post-installer for moriarty when it's being installed by neet.
PREFIX=/opt
if [ ! -z $1 ] && [ -d "$1" ]; then
	PREFIX="$1"
fi

MORIARTY="${PREFIX}/neet/pkg/moriarty"
for script in opwg oquery osd ose otnsctl; do
	cat ${script}.sh  | sed -e "s?__MORIARTY__?$MORIARTY?" > ${script}.sh.corrected
	mv ${script}.sh.corrected ${script}.sh
	chmod 755 ${script}.sh
done

rm -f post-install.sh
