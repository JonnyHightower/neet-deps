#!/bin/sh
#
# Wrapper for OraclePWGuess by patrik.karlsson@ixsecurity.com
# Wrapped for neet by Jonathan Roach
#
BASE=__MORIARTY__
OWD="$PWD"
cd "$BASE"
JAVA=java
JDBC=classes12.jar
$JAVA -cp .:$JDBC:ork.jar ork.OraclePwGuess $*
cd "$OWD"
