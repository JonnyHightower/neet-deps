/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package ork;

import java.sql.*;
import java.util.*;
import java.io.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OracleQuery {

    static Connection m_oConn = null;
    static boolean m_bDebug = false; /* should we be verbose or not */

    private static String m_sVersion = OATVersion.getVersion();
    private static String m_sAuthor = OATVersion.getAuthor();
    private static String m_sProgramName = "OracleQuery";
    
    /*
      wrapper for execute query
     */
    private static void exec(String sQuery) {

	try {
	    Statement oStmt = m_oConn.createStatement();
	    oStmt.executeQuery(sQuery);
	}
	catch ( SQLException e ) {
	    System.out.println("ERROR: " + sQuery);
	    //e.printStackTrace();
	}

    }

    private static ResultSet getResult(String sQuery) {

	try {
	    Statement oStmt = m_oConn.createStatement();
	    oStmt.execute(sQuery);
	    return oStmt.getResultSet();
	}
	catch ( SQLException e ) {
	    System.out.println("ERROR: " + sQuery);
	    System.err.println(e.getMessage());
	    return null;
	}

    }

    private static void usage() {

	System.out.println("\t" + m_sProgramName + " " + m_sVersion + m_sAuthor );
	System.out.println("\t----------------------------------------");
	System.out.println("\t" + m_sProgramName +" [options]");
	System.out.println("\t\t-s*\t<servername>");
	System.out.println("\t\t-u*\t<username>");
	System.out.println("\t\t-p*\t<password>");
	System.out.println("\t\t-d*\t<SID>");
	System.out.println("\t\t-P\t<portnr>");
	System.out.println("\t\t-v\tbe verbose");
	System.out.println("\t\t-q\t<query>");
	System.out.println("\t\t-o\t<outfile>");
	System.out.println("\t\t-m\t<tabledelimiter>");
	System.out.println("");

    }

    /*
      Main function
    */
    public static void main (String args []) {

	String sHostName = null;
	String sDataBase = null;
	String sUserName = null;
	String sPassWord = null;
	String sLogFile = null;
	String sDelimiter = null;
	String sQuery = null;

	int nOraclePort = 1521;
	Getopt oOpt = new Getopt("OracleQuery", args, "s:d:u:p:hP:vT:m:o:q:");
	int c;
	String arg;
	OracleTNSSocket oTNSSock;

	String sConnectionURL = null;

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {

	    switch( c ) {

	    case 'q':
		arg = oOpt.getOptarg();
		sQuery = arg;
		break;

	    case 'o':
		arg = oOpt.getOptarg();
		sLogFile = arg;
		break;
		
	    case 'm':
		arg = oOpt.getOptarg();
		sDelimiter = arg;
		break;

	    case 's':
		arg = oOpt.getOptarg();
		sHostName = arg;
		break;
		
	    case 'd':
		arg = oOpt.getOptarg();
		sDataBase = arg;
		if ( sDataBase == null || sDataBase.length() == 0 ) {
		    System.err.println("ERROR: An Oracle sid has to be specified.");
		    System.exit(1);
		}

		break;

	    case 'u':
		arg = oOpt.getOptarg();
		sUserName = arg;
		break;
		
	    case 'p':
		arg = oOpt.getOptarg();
		sPassWord = arg;
		break;

	    case 'P':
		arg = oOpt.getOptarg();
		nOraclePort = Integer.parseInt(arg);
		break;

	    case 'h':
		usage();
		System.exit(1);
		break;

	    case 'v':
		m_bDebug = true;
		break;

	    default:
		usage();
		System.exit(0);
	    }

	}

	/* do we have all the parameters needed */
	if ( sHostName == null || sDataBase == null ) {
	    usage();
	    System.exit(0);
	}

	/* Do some bragging */
	System.out.println( m_sProgramName + " " + m_sVersion + " by " + m_sAuthor );
	System.out.println("----------------------------------------");

	/* build a connection URL based on the input */
	sConnectionURL = "jdbc:oracle:thin:@" + sHostName + ":" + nOraclePort;
	sConnectionURL += ":" + sDataBase;

	/*
	  Lets try to load the Oracle JDBC driver
	*/
	try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	}
	catch( ClassNotFoundException e ) {
	    System.err.println("ERROR: Could not load JDBC driver. Make sure it's in the classpath");
	    System.exit(1);
	}

	if ( sUserName != null && sPassWord != null ) {

	    /*
	      Ok so the Driver loaded, let's try to login
	    */
	    try {
		m_oConn = DriverManager.getConnection (sConnectionURL,sUserName, sPassWord);
	    }
	    catch ( SQLException e ) {
		//e.printStackTrace();
		System.out.println("ERROR: Could not connect to ORACLE server.");
		System.exit(0);
	    }

	}
	else {
	    System.out.println("ERROR: Please supply a valid username and password");
	    System.exit(1);
	}

	if ( m_oConn == null ) {
	    System.out.println("ERROR: Failed to connect to ORACLE server");
	    System.exit(1);
	}

	String sCmd = "";
	LineNumberReader oInReader = new LineNumberReader( new InputStreamReader( System.in ) );
	ResultSet oRS = null;
	FmtResultSet oFmtRS = null;
	PrintStream oPS = System.out;

	
	/* Setup output file */
	try {
	    if ( sLogFile != null )
		oPS = new PrintStream( new FileOutputStream( sLogFile ) );
	}
	catch( FileNotFoundException e ) {
	    System.out.println("ERROR: Could not create logfile");
	    System.exit(1);
	}


	/* Should we start in interactive mode, or just execute a query and exit ?! */
	while ( sCmd != null && !sCmd.equalsIgnoreCase("quit") ) {

	    oRS = null;
	    oFmtRS = null;

	    /* do we have a query */
	    if ( sQuery != null ) {
		sCmd = sQuery;
	    }
	    else {
		try {
		    System.out.print("pl/sql> ");
		    sCmd = oInReader.readLine();
		}
		catch ( IOException e ) {
		    e.printStackTrace();
		}
	    }
	    
	    if ( sCmd!= null && !sCmd.equalsIgnoreCase("quit") && 
		 sCmd.length() > 0 ) {

		oRS   = getResult(sCmd);
		
		/* did we actually get something back from the query */
		if ( oRS != null ) {
		    oFmtRS = new FmtResultSet( oRS );
		    oFmtRS.setDelimiter(sDelimiter);
		}

		try {

		    if ( oFmtRS != null ) {
			oFmtRS.outputHeaders(oPS);
			oFmtRS.outputData(oPS);
		    }
		    
		    if ( oRS != null )
			oRS.close();

		    if ( oFmtRS != null )
			oFmtRS.close();

		}
		catch ( SQLException e ) {
		    e.printStackTrace();
		} /* end catch */

	    } /* end if */

	    /* if we where called with a query, break out from while loop */
	    if ( sQuery != null )
		break;

	} /* end while */

    } /* end main */
	
} /* end class */
