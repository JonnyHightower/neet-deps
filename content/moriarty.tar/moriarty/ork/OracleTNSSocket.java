/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
  Changes
  2002-06-03 : Changed logic to primarly look for INSTANCE_NAME then SERVICE_NAME
  2002-09-15 : Changed getOracleVersion to return "unknown" instead of null when it failed to
               retrieve the version. Added some error information to the same function.

*/

package ork;

import java.sql.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.lang.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OracleTNSSocket {

    private int m_nPort = 1521;
    private String m_sHost = null;
    private Socket m_oSocket = null;
    private InputStream m_oInStream;
    private OutputStream m_oOutStream;
    private String m_sUserName = "Administrator";
    private String m_sPassWord = null;
    private String m_sOracleVersion = null;

    public OracleTNSSocket() {

    }

    public OracleTNSSocket(String sHost, int nPort) {
	m_sHost = sHost;
	m_nPort = nPort;
    }

    public String getOracleVersion() {

	if ( m_sOracleVersion == null ) {

	    String sAnswer = null;
	    String sVersionKey = "VERSION=";
	    int nPos = 0;
	    byte buf2[] = null;

	    /* Some beautiful code duplication from getsids.... */

	    /* we might have an error here */
	    if ( sendTNSCommand("status") != true ) {
		System.err.println("ERROR: TNS-status request failed");
		return "unknown"; /* The Oracle Version is unknown */
	    }

	    byte buf[] = recvCommandAnswer();

	    /* the status command returned accept */
	    if ( buf[4] == 2 ) {

		while ( ( buf2 = recvCommandAnswer() ) != null ) {

		    /* ellol ! */
		    if ( buf2 == null ) {
			System.err.println("ERROR: TNS-status request unknown error");
			return "unknown"; /* The Oracle Version is unknown */
		    }

		    sAnswer += new String(buf2);

		}

		if ( sAnswer == null ) {
		    System.err.println("ERROR: TNS-status request failed to return parameters");
		    return "unknown"; /* The Oracle Version is unknown */
		}

		/* Try to dig out the version */
		while ( ( nPos = sAnswer.indexOf( sVersionKey, nPos ) ) != -1 ) {
		    nPos += sVersionKey.length();
		    m_sOracleVersion = sAnswer.substring( nPos, sAnswer.indexOf(")", nPos) );
		} /* end while */

	    } /* end if */

	} /* end if oracle version is null */

	return m_sOracleVersion;
    }
    
    /* close all streams and sockets */
    public void close() {

	try {
	    if ( m_oInStream != null )
		m_oInStream.close();

	    if ( m_oOutStream != null )
		m_oOutStream.close();

	    if ( m_oSocket != null )
		m_oSocket.close();
	}
	catch ( IOException e ) {
	    System.err.println("ERROR: OracleTNSSocket.close()");
	    System.exit(1);
	}

    }

    /* returns the local IP of the connected socket as string */
    public String getLocalIP() {
	return m_oSocket.getLocalAddress().getHostAddress();
    }

    public boolean connect() {

	if ( m_sHost == null ) {
	    System.err.println("ERROR: Hostname not set ! Use setHost()");
	    return false;
	}

	try {
	    m_oSocket = new Socket( m_sHost, m_nPort );
	}
	catch( IOException e ) {
	    return false;
	}

	/* register the cool streams */
	try {
	    m_oInStream = new BufferedInputStream( m_oSocket.getInputStream() );
	    m_oOutStream = new BufferedOutputStream( m_oSocket.getOutputStream() );
	}
	catch( IOException e ) {
	    e.printStackTrace();
	}

	return true;
    }

    public Vector getOracleSIDS() {

	Vector oVector = new Vector();
	String sAnswer = null;
	String sKey = "SERVICE_NAME=";
	String sKey2 = "SID=";
	String sKeyInstance = "INSTANCE_NAME=";
	String sVersionKey = "VERSION=";
	String sSID = null;
	int nPos = 0;
	byte buf2[] = null;

	/* we might have an error here */
	if ( sendTNSCommand("status") != true )
	    return null;

	byte buf[] = recvCommandAnswer();

	/* the status command returned accept */
	if ( buf[4] == 2 ) {

	    while ( ( buf2 = recvCommandAnswer() ) != null ) {

		/* ellol ! */
		if ( buf2 == null )
		    return null;

		sAnswer += new String(buf2);

	    }

	    if ( sAnswer == null )
		return null;

	    /* Try to dig out the version */
	    while ( ( nPos = sAnswer.indexOf( sVersionKey, nPos ) ) != -1 ) {
		nPos += sVersionKey.length();
		m_sOracleVersion = sAnswer.substring( nPos, sAnswer.indexOf(")", nPos) );
		oVector.add ( m_sOracleVersion );    
	    }
	    nPos = 0;
	       
	    /* look for INSTANCE_NAME= */
	    while ( ( nPos = sAnswer.indexOf( sKeyInstance, nPos ) ) != -1 ) {
		nPos += sKeyInstance.length();
		sSID = sAnswer.substring( nPos, sAnswer.indexOf( ")", nPos ) );
		// System.out.println( sSID );
		oVector.add ( sSID );
	    }
	    
	    nPos = 0;

	    if ( oVector.size() == 0 ) {

		/* look for SERVICE_NAME= */
		while ( ( nPos = sAnswer.indexOf( sKey, nPos ) ) != -1 ) {
		    nPos += sKey.length();
		    sSID = sAnswer.substring( nPos, sAnswer.indexOf( ")", nPos ) );
		    // System.out.println( sSID );
		    oVector.add ( sSID );
		}

	    }
	    
	    nPos = 0;

	    /* did we get anything or should we try something else */
	    /* look for SID=*/
	    if ( oVector.size() == 0 ) {

		while ( ( nPos = sAnswer.indexOf( sKey2, nPos ) ) != -1 ) {
		    nPos += sKey2.length();
		    sSID = sAnswer.substring( nPos, sAnswer.indexOf( ")", nPos ) );
		    oVector.add ( sSID );
		}

	    }

	}
	else
	    return null; // The status command was denied

	/* remove duplicates */
	int nDupPos = 0;
	boolean bRemoved = false;

	while ( nDupPos < oVector.size() ) {

	    for ( int i=nDupPos+1; i<oVector.size(); i++ ) {
		if ( ((String)oVector.get(nDupPos)).equals( (String)oVector.get(i) ) ) {
		    oVector.remove(i);
		    bRemoved = true;
		}
	    }

	    if ( !bRemoved )
		nDupPos ++;

	    bRemoved = false;
	}


	return oVector;
    }

    public boolean sendCommand(String sCommand) {
	return sendTNSCommand(sCommand);
    }

    public byte[] recvCommandAnswer() {
	
	int nSize = 1024;
	int nRetries = 10000;
	int nRet = -1;
	
	try {

	    byte buf[] = new byte[nSize];

	    while ( nRetries != 0 && nRet == -1 ) {
		nRet = m_oInStream.read(buf, 0, nSize);
		nRetries --;
	    }

	    if ( nRet == -1 )
		return null;
	    else
		return buf;
	}
	catch( IOException e ) {
	    /* Dont print this crap :) */
	    /* e.printStackTrace(); */
	}
	
	return null;
    }

    public void setTNSPassword(String sPassWord) {
	m_sPassWord = sPassWord;
    }

    private boolean sendTNSCommand(String sCommand) {

	int bBuf[] = {0x00, 0xc7, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x36, 0x01, 0x2c, 0x00, 0x00, 0x08, 0x00,
		      0x7f, 0xff, 0x7f, 0x08, 0x00, 0x00, 0x01, 0x00, 0x00, 0x8d, 0x00, 0x3a, 0x00, 0x00, 0x07, 0xf8,
		      0x0c, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x93, 0x00, 0x00,
		      0x04, 0x32, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x28, 0x44, 0x45, 0x53, 0x43, 0x52,
		      0x49, 0x50, 0x54, 0x49, 0x4f, 0x4e, 0x3d, 0x28, 0x43, 0x4f, 0x4e, 0x4e, 0x45, 0x43, 0x54, 0x5f,
		      0x44, 0x41, 0x54, 0x41, 0x3d, 0x28, 0x43, 0x49, 0x44, 0x3d, 0x28, 0x50, 0x52, 0x4f, 0x47, 0x52,
		      0x41, 0x4d, 0x3d, 0x29, 0x28, 0x48, 0x4f, 0x53, 0x54, 0x3d, 0x29};
	
	int bBuf2[] = {
		       0x28, 0x53, 0x45, 0x52, 0x56, 0x49, 0x43, 0x45, 0x3d, 0x4c, 0x49, 0x53, 0x54, 0x45, 0x4e, 
		       0x45, 0x52, 0x29, 0x28, 0x56, 0x45, 0x52, 0x53, 0x49, 0x4f, 0x4e, 0x3d, 0x31, 0x33, 0x35,
		       0x32, 0x39, 0x34, 0x39, 0x37, 0x36, 0x29, 0x29, 0x29};
	
	bBuf[1] = 178 + sCommand.length() + m_sUserName.length();
	bBuf[25] = 120 + sCommand.length() + m_sUserName.length();

	/* Make sure we have a valid out stream */
	if ( m_oOutStream == null )
	    return false;

	try {

	    if ( m_sPassWord != null ) {
		bBuf[1] += (new String("(PASSWORD=" + m_sPassWord+ ")")).length();
		bBuf[25]+= (new String("(PASSWORD=" + m_sPassWord+ ")")).length();
	    }

	    for ( int i=0; i<bBuf.length; i++ )
		m_oOutStream.write( bBuf[i] );

	    m_oOutStream.write( new String("(USER=" + m_sUserName + "))").getBytes() );
	    m_oOutStream.write( new String("(COMMAND=" + sCommand + ")").getBytes() );
	    m_oOutStream.write( new String("(ARGUMENTS=64)").getBytes() );

	    if ( m_sPassWord != null ) {
		m_oOutStream.write( new String("(PASSWORD="+ m_sPassWord+ ")").getBytes() );
	    }

	    for ( int i=0; i<bBuf2.length; i++ )
		m_oOutStream.write( bBuf2[i] );

	    m_oOutStream.flush();

	}
	catch ( IOException e ) {
	    e.printStackTrace();
	    return false;
	}

	return true;

    }


    public void setHost(String sHost) {
	m_sHost = sHost;
    }
    
    

}
