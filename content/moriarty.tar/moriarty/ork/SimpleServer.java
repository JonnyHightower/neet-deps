/**
 * SimpleServer.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * This is a simple command line implementation of a front end for
 * JTftpServer. See TftpSAServer.java for a GUI front end example.
 */

package ork;

import java.net.InetAddress;
import tftp.TftpIface;
import tftp.Utility;
import tftp.io.ServerThread;
import tftp.event.TftpEvent;
import tftp.event.TftpEventListener;

public class SimpleServer implements TftpIface, TftpEventListener
{
    ServerThread st;

    public SimpleServer()
    {
	st = new ServerThread (this, 69);
	st.addTftpEventListener (this);
	st.start();
    }

    public void stopServer() {
	st.interrupt();
	st.stopServer();
    }

    /*
    public static void main(String[] args)
    {
	SimpleServer sc = new SimpleServer();
    }
    */

    public int getRetransmitCount (InetAddress inAddr) {
      return 5;
    }

    public int getTimeout (InetAddress inAddr) {
      return 5000;
    }

    public void logMessage (InetAddress inAddr, int level, String message) {
      System.err.println (inAddr.getAddress() + "[" + level + "] "
			  + message);
    }

    public void logMessage (String inAddr, int level, String message) {
      System.err.println (inAddr + "[" + level + "] "
			  + message);
    }

    public boolean getAllowWrite(InetAddress inAddr)
    {
      return true;
    }

    public boolean getAllowRead(InetAddress inAddr)
    {
      return true;
    }

    public boolean getAllowOverWrite(InetAddress inAddr)
    {
      return true;
    }

    public String getBasePath(InetAddress inAddr)
    {
	return "tftproot";
    }

    public void tftpMessage(TftpEvent te)
    {
      switch (te.getID()) {
          case TftpEvent.REQUEST_RECEIVED:
	    System.err.println ("INFO: Recieved " + ((te.getType() == Utility.RRQ_PACKET)?"read":"write") + " request from " + (te.getAddress()));
	    break;
      case TftpEvent.REQUEST_COMPLETE:
	    System.err.println ("INFO: Completed " + ((te.getType() == Utility.RRQ_PACKET)?"read":"write") + " request from " + (te.getAddress()));
	    break;
      case TftpEvent.REQUEST_INCOMPLETE:
	    System.err.println ("ERROR: Error on request from " + te.getAddress() + ": " + (te.getArg()));
	    break;
      default:
	break;
      }
    }
}



