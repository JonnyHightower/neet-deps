/**
 * ServerThread.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */
package tftp.io;
import tftp.Utility;
import tftp.TftpIface;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Hashtable;
import java.util.Vector;

import tftp.event.*;

public class ServerThread extends Thread
{
    
    boolean m_bRunning = true;
    
    public ServerThread(TftpIface iface)
    {
        this(iface, DEFAULT_PORT);
    }

    public ServerThread(TftpIface iface, int port)
    {
        if (iface == null) {
	  throw new IllegalArgumentException ("Null TftpIface object");
	} else {
	  this.listeners = new Vector();
	  this.iface = iface;
	  try {
	    serverPort = port;
	    serverSocket = new DatagramSocket(port);
	    serverSocket.setSoTimeout(100);
	    inPacket = new DatagramPacket (new byte[PACKET_SIZE],
					   PACKET_SIZE);
	    workerHash = new Hashtable (64);
	  } catch (SocketException se) {
	    iface.logMessage ("SYSTEM", 0, 
			      "Could not open tftp server socket "
			      + "on port " + port);
	  }
	}
    }

    public void stopServer() {
	this.interrupt();
	m_bRunning = false;
    }

    public void run()
    {
	int opcode;
	boolean canRead, canWrite, bTimeout = false;
	
	iface.logMessage ("SERVER:", 2,
			  "Tftp Server thread started.");
	while ( m_bRunning ) {
	    try {
		serverSocket.receive (inPacket);
		bTimeout = false;
	    }
	    catch ( java.io.InterruptedIOException e ) {
		bTimeout = true;
	    } catch (IOException ioe) {
	      iface.logMessage ("SERVER:", 2,
			  "Tftp Server thread socket error.");
	    }

	    if ( !bTimeout ) {
		opcode = Utility.fetchOpcode (inPacket.getData());
		dispatchTftpEvent (new TftpEvent (this, 
						  inPacket.getAddress(),
						  inPacket.getPort(),
						  TftpEvent.REQUEST_RECEIVED,
						  opcode,
						  null));
		canRead = iface.getAllowRead(inPacket.getAddress());
		canWrite = iface.getAllowWrite(inPacket.getAddress());
		if (opcode == Utility.RRQ_PACKET 
		    && !canRead) {
		    iface.logMessage (inPacket.getAddress(),
				      2,
				      "Read requests not allowed for this client.");
		}
		if (opcode == Utility.WRQ_PACKET 
		    && !canWrite) {
		    iface.logMessage (inPacket.getAddress(),
				      2,
				      "Write requests not allowed for this client.");
		}
		if ((opcode == Utility.RRQ_PACKET
		     && canRead) 
		    || (opcode == Utility.WRQ_PACKET &&
			canWrite)) {
		    WorkerThread ct = new WorkerThread (this, iface, inPacket);
		    workerHash.put (ct.getID(), ct);
		    ct.start();

		}

	    }
	}
	/*iface.logMessage ("SERVER:", 2,
			  "Tftp Server thread stopped.");*/
    }

    public void workerTerminated(String id)
    {
	workerHash.remove (id);
    }

    public void dispatchTftpEvent(TftpEvent te)
    {
      TftpEventListener tl;
      for (int i = 0; i < listeners.size(); i++) {
	tl = (TftpEventListener)listeners.elementAt (i);
	tl.tftpMessage (te);
      }
    }

    public void addTftpEventListener(TftpEventListener l)
    {
      listeners.addElement (l);
    }

    public void removeTftpEventListener(TftpEventListener l)
    {
      listeners.removeElement (l);
    }

    Vector listeners;

    TftpIface iface = null;
    Hashtable workerHash;
    DatagramPacket inPacket;
    DatagramSocket serverSocket;
    

    private int serverPort;
    final static int DEFAULT_PORT = 69;
    final static int PACKET_SIZE  = 528;

}
