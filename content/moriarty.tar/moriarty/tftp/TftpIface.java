/**
 * TftpIface.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */
package tftp;

import java.net.InetAddress;
public interface TftpIface
{
    public boolean getAllowOverWrite(InetAddress inAddr);
    public boolean getAllowWrite(InetAddress inAddr);
    public boolean getAllowRead(InetAddress inAddr);
    public int getRetransmitCount (InetAddress inAddr);
    public int getTimeout (InetAddress inAddr);
    public void logMessage (String source, int level, String message);
    public void logMessage (InetAddress inAddr, int level, String message);
    public String getBasePath(InetAddress inAddr);
}
