#!/bin/bash

##########################################################################
#
#    Neet: Network discovery, enumeration and security assessment tool
#    Copyright (C) 2008-2016 Jonathan Roach
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Contact: jonnyhightower [at] funkygeek.com
#
##########################################################################

# Installer for Winexe 1.1
ERR=1
PREFIX="$1/neet/pkg"
PKG="$2"
LOGFILE="$3"

rm -f "$LOGFILE"

WORKDIR="$PWD"
unset MISSING
for package in git gcc-mingw-w64 comerr-dev libpopt-dev libbsd-dev zlib1g-dev\
							 libc6-dev python-dev libacl1-dev libldap2-dev; do
	if apt-cache policy $package 2>&1 | grep -qi "Installed: (none)"; then
		MISSING="$MISSING $package"
	fi
done
if [ ! -z "$MISSING" ]; then
	echo "ALERT! missing dependencies for building winexe-1.1. Installing the following packages via apt-get:"
	echo $MISSING
	#echo "Would you like me to install them? [Y/n]"
	#read -sn1 response
	#if [ "$response" == "n" ] || [ [ "$response" == "N" ]; then
	#	echo "Not installing winexe-1.1"
	#	exit 1
	#else
	#	echo "Installing pre-requisites."
	apt-get install -y $MISSING >> "$LOGFILE" 2>&1
	#fi
fi

# Ensure we have the correct version of Samba
if [ ! -d samba ]; then
	echo "Fetching latest version of Samba from Samba's GIT repo (about 290MB)..." | tee -a "$LOGFILE" 2>&1
	git clone git://git.samba.org/samba.git samba | tee -a "$LOGFILE" 2>&1
	if [ -d samba/source4 ]; then
		echo "Downloaded OK. Resetting to specific release."  | tee -a "$LOGFILE" 2>&1
		cd samba
		git reset --hard a6bda1f2bc85779feb9680bc74821da5ccd401c5  >> "$LOGFILE" 2>&1
		cd ..
	fi
fi

# Get Winexe WAF
if [ ! -d winexe-winexe-waf/source ]; then
	echo "Fetching latest winexe from the GIT repo" | tee -a "$LOGFILE" 2>&1
	git clone git://git.code.sf.net/p/winexe/winexe-waf winexe-winexe-waf  >> "$LOGFILE" 2>&1
fi

if [ ! -d winexe-winexe-waf/source ] || [ ! -d samba/source4 ]; then
	echo "Something has gone wrong with the retrieval." | tee -a "$LOGFILE" 2>&1
	exit 2
fi

# Patch samba if necessary
if [ -L /usr/lib/x86_64-linux-gnu/libgnutls.so.30 ]; then
	# Patch for GnuTLS >= 3.0
	echo " +  Patching Samba for GnuTLS 3.0+" | tee -a "$LOGFILE" 2>&1
	for file in tls.c tls_tstream.c; do
		cat samba/source4/lib/tls/$file | grep -v gnutls_certificate_type_set_priority | grep -v gnutls_transport_set_lowat > samba/source4/lib/tls/tls.tmp
		mv samba/source4/lib/tls/tls.tmp samba/source4/lib/tls/$file
	done
fi

# Now patch winexe
echo " +  Preparing winexe 1.1 source"  | tee -a "$LOGFILE" 2>&1
cd winexe-winexe-waf/source
sed -i wscript_build -e "s/lib='dl'/lib='dl gnutls gcrypt'/"

# Rename the service executable
NEWSERVICENAME=neetcmdsvc
echo " +  Renaming winexesvc to $NEWSERVICENAME" | tee -a "$LOGFILE" 2>&1
for file in svcinstall.c winexe.c winexesvc.h winexesvc_launch.c winexesvc_loop.c wscript_build; do
	sed -i $file -e "s/winexesvc/$NEWSERVICENAME/g"
done
mv winexesvc.h ${NEWSERVICENAME}.h
mv winexesvc_launch.c ${NEWSERVICENAME}_launch.c
mv winexesvc_loop.c ${NEWSERVICENAME}_loop.c

# Do the build
echo " +  Building winexe 1.1 from source"  | tee -a "$LOGFILE" 2>&1
./waf --samba-dir=../../samba configure build  >> "$LOGFILE" 2>&1
ERR=$?

if [ -x build/winexe-static ]; then
	echo " +  Installing winexe 1.1 to $PREFIX/bin/winexe"  | tee -a "$LOGFILE" 2>&1
	cp build/winexe-static "$PREFIX/bin/winexe"
	chown root.root "$PREFIX/bin/winexe"
	cd "$WORKDIR"
	echo " +  Cleaning up (in $PWD)" | tee -a "$LOGFILE" 2>&1
	rm -rf samba winexe-winexe-waf
	ERR=0
fi

exit $ERR

